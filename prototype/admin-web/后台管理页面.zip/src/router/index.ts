import { createRouter, createWebHashHistory } from 'vue-router'

const router = createRouter({
  history: createWebHashHistory(),
  routes: [
    { path: '/login', name: 'Login', component: () => import('@/views/Login.vue'), meta: { title: '登录', noAuth: true } },
    { path: '/', redirect: '/dashboard' },
    { path: '/dashboard', name: 'Dashboard', component: () => import('@/views/Dashboard.vue'), meta: { title: '门店总览' } },
    { path: '/rooms', name: 'RoomManagement', component: () => import('@/views/RoomManagement.vue'), meta: { title: '房间管理' } },
    { path: '/room-detail/:roomId', name: 'RoomDetail', component: () => import('@/views/RoomDetail.vue'), meta: { title: '房间详情' } },
    { path: '/devices', name: 'DeviceManagement', component: () => import('@/views/DeviceManagement.vue'), meta: { title: 'IoT设备管理' } },
    { path: '/scenes', name: 'SceneConfig', component: () => import('@/views/SceneConfig.vue'), meta: { title: '场景配置' } },
    { path: '/alerts', name: 'AlertCenter', component: () => import('@/views/AlertCenter.vue'), meta: { title: '告警中心' } },
    { path: '/audit', name: 'AuditLog', component: () => import('@/views/AuditLog.vue'), meta: { title: '操作审计' } },
  ]
})

router.beforeEach((to, _from, next) => {
  if (to.meta.noAuth) {
    next()
    return
  }
  const loggedIn = localStorage.getItem('erp_logged_in')
  if (loggedIn === 'true') {
    next()
  } else {
    next('/login')
  }
})

export default router
