<template>
  <!-- Login page: clean layout, no sidebar/header -->
  <router-view v-if="isLoginPage" />

  <!-- Authenticated layout: sidebar + header + content -->
  <t-layout class="app-layout" v-else>
    <aside class="app-aside">
      <div class="sidebar-header">
        <span class="logo-text">高岸ERP</span>
        <span class="logo-sub">盈隆店</span>
      </div>
      <t-menu
        :value="activeMenu"
        theme="dark"
        @change="onMenuChange"
      >
        <t-menu-item value="/dashboard">
          <template #icon><t-icon name="dashboard" /></template>
          门店总览
        </t-menu-item>
        <t-menu-item value="/rooms">
          <template #icon><t-icon name="room" /></template>
          房间管理
        </t-menu-item>
        <t-menu-item value="/devices">
          <template #icon><t-icon name="server" /></template>
          IoT设备管理
        </t-menu-item>
        <t-menu-item value="/scenes">
          <template #icon><t-icon name="control-platform" /></template>
          场景配置
        </t-menu-item>
        <t-menu-item value="/alerts">
          <template #icon><t-icon name="error-circle" /></template>
          告警中心
          <t-badge v-if="alertCount" :count="alertCount" style="margin-left:8px" />
        </t-menu-item>
        <t-menu-item value="/audit">
          <template #icon><t-icon name="file-search" /></template>
          操作审计
        </t-menu-item>
      </t-menu>
    </aside>
    <t-layout>
      <t-header class="app-header">
        <div class="header-left">
          <span class="page-title">{{ pageTitle }}</span>
        </div>
        <div class="header-right">
          <t-tag v-if="alertCount" theme="danger" variant="light" style="cursor:pointer" @click="router.push('/alerts')">
            ⚠ {{ alertCount }} 条告警
          </t-tag>
          <t-tag theme="success" variant="light">系统运行中</t-tag>
          <t-tag variant="light">{{ currentTime }}</t-tag>
          <span class="user-info" v-if="currentUser">
            <t-icon name="user-circle" size="18px" />
            {{ currentUser }}
          </span>
          <t-button size="small" variant="text" @click="handleLogout">退出登录</t-button>
        </div>
      </t-header>
      <t-content class="app-content">
        <router-view />
      </t-content>
    </t-layout>
  </t-layout>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { alerts } from '@/mock/data'

const router = useRouter()
const route = useRoute()

const currentTime = ref('')
let timer: ReturnType<typeof setInterval>

const isLoginPage = computed(() => route.meta.noAuth === true)
const currentUser = computed(() => localStorage.getItem('erp_user'))
const activeMenu = computed(() => {
  if (route.path.startsWith('/room-detail')) return '/rooms'
  return route.path
})
const pageTitle = computed(() => (route.meta.title as string) || '')

const alertCount = computed(() => {
  return alerts.alerts.filter(a => a.status === 'Unresolved').length
})

function onMenuChange(value: string) {
  router.push(value)
}

function handleLogout() {
  localStorage.removeItem('erp_logged_in')
  localStorage.removeItem('erp_user')
  router.push('/login')
}

function updateTime() {
  const now = new Date()
  currentTime.value = now.toLocaleString('zh-CN', { hour12: false })
}

onMounted(() => {
  updateTime()
  timer = setInterval(updateTime, 1000)
})

onUnmounted(() => {
  clearInterval(timer)
})
</script>

<style>
* { margin: 0; padding: 0; box-sizing: border-box; }

.app-layout { height: 100vh; }

.app-aside {
  width: 200px;
  min-width: 200px;
  background: #1a1a1a !important;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.sidebar-header {
  padding: 20px 16px;
  text-align: center;
  border-bottom: 1px solid rgba(255,255,255,0.1);
  flex-shrink: 0;
}
.logo-text {
  display: block;
  color: #fff;
  font-size: 18px;
  font-weight: 700;
  letter-spacing: 2px;
}
.logo-sub {
  display: block;
  color: rgba(255,255,255,0.5);
  font-size: 12px;
  margin-top: 4px;
}

.app-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 20px;
  background: #fff;
  border-bottom: 1px solid #e7e7e7;
  height: 56px;
}
.header-left { display: flex; align-items: center; }
.page-title { font-size: 16px; font-weight: 600; color: #333; }
.header-right { display: flex; align-items: center; gap: 12px; }

.user-info {
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: 13px;
  color: #333;
  font-weight: 500;
}

.app-content {
  padding: 20px;
  background: #f5f7fa;
  overflow-y: auto;
}
</style>
